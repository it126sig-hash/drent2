<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\BookingDetail;
use App\Models\BookingPayment;
use App\Models\Invoice;
use App\Models\InvoiceHistory;
use App\Models\InvoiceInvoice;
use App\Models\Payment;
use App\Models\PaymentAccount;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use App\Services\PaymentAccountTransactionService;

class ReceivableService
{
    public function __construct(
        private BookingBillingService $billingService,
        private PaymentAccountTransactionService $transactionService
    ) {}

    public function list(array $filters = []): LengthAwarePaginator
    {
        $perPage = (int) ($filters['per_page'] ?? 15);

        $paginator = Booking::query()
            ->with([
                'customer.member',
                'bookingDetails.unit.rentalOwner',
                'bookingDetails.driver',
                'bookingDetails.costs',
                'payments',
                'invoices' => fn($query) => $query
                    ->where('status', '!=', 'void')
                    ->with(['payments.paymentAccount', 'payments.bookingPayments', 'creator', 'sentBy', 'mergedInto', 'voidRequester'])
                    ->latest('generated_at'),
            ])
            ->when($filters['tenant_id'] ?? null, fn($query, $tenantId) => $query->where('tenant_id', $tenantId))
            ->when($filters['branch_id'] ?? null, fn($query, $branchId) => $query->where('branch_id', $branchId))
            ->when($filters['kota'] ?? null, fn($query, $kota) => $query->where('kota', $kota))
            ->when($filters['search'] ?? null, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('kode_booking', 'like', "%{$search}%")
                        ->orWhere('tujuan', 'like', "%{$search}%")
                        ->orWhere('kota', 'like', "%{$search}%")
                        ->orWhereHas('customer', fn($customer) => $customer->where('nama', 'like', "%{$search}%"))
                        ->orWhereHas('bookingDetails.unit', function ($unit) use ($search) {
                            $unit->where('merk', 'like', "%{$search}%")
                                ->orWhere('tipe', 'like', "%{$search}%")
                                ->orWhere('no_polisi', 'like', "%{$search}%");
                        })
                        ->orWhereHas('invoices', fn($invoice) => $invoice->where('invoice_number', 'like', "%{$search}%"));
                });
            })
            ->whereNotIn('status', ['batal'])
            // Sembunyikan booking yang sudah lunas total (sisa 0) — termasuk performance
            // pre-filter via kolom cached, accurate re-check dilakukan di PHP setelah load.
            ->when(
                ($filters['invoice_status'] ?? null) !== 'changed',
                fn($query) => $query->where('cached_sisa_tagihan', '>', 0)
            )
            ->when($filters['invoice_status'] ?? null, function ($query, $status) {
                if (in_array($status, ['generated', 'changed'], true)) {
                    $query->whereHas('invoices', fn($invoice) => $invoice
                        ->whereNotIn('status', ['void', 'paid'])
                        ->whereColumn('paid_amount', '<', 'total_amount'));
                }

                if ($status === 'not_generated') {
                    $query->whereDoesntHave('invoices', fn($invoice) => $invoice
                        ->whereNotIn('status', ['void', 'paid'])
                        ->whereColumn('paid_amount', '<', 'total_amount'));
                }
            })
            ->latest()
            ->paginate($perPage);

        // Enrich hanya rows pada halaman ini (max $perPage rows, bukan semua data)
        $paginator->getCollection()->transform(function (Booking $booking) use ($filters) {
            $totalTagihan = $this->billingService->totalTagihan($booking);
            $totalPayments = $this->billingService->paidAmount($booking);
            $sisaTagihan = max(0, $totalTagihan - $totalPayments);

            if ((int) $booking->cached_sisa_tagihan !== (int) $sisaTagihan) {
                DB::table('bookings')
                    ->where('id', $booking->id)
                    ->update(['cached_sisa_tagihan' => (int) $sisaTagihan]);
                $booking->cached_sisa_tagihan = (int) $sisaTagihan;
            }

            $booking->total_tagihan = $totalTagihan;
            $booking->total_payments = $totalPayments;
            $booking->sisa_tagihan = $sisaTagihan;
            $booking->latest_active_invoice = $booking->invoices
                ->first(fn(Invoice $invoice) => $invoice->status !== 'paid' && $this->invoiceRemaining($invoice) > 0);
            $booking->invoice_reconciliation = $booking->latest_active_invoice
                ? $this->invoiceReconciliation($booking->latest_active_invoice)
                : null;
            $booking->latest_paid_invoice = (! $booking->latest_active_invoice)
                ? $booking->invoices->first(fn(Invoice $invoice) => $invoice->status === 'paid')
                : null;
            $booking->paid_invoice_reconciliation = $booking->latest_paid_invoice
                ? $this->invoiceReconciliation($booking->latest_paid_invoice)
                : null;
            $booking->display_detail = $booking->bookingDetails->firstWhere('status', 'aktif')
                ?? $booking->bookingDetails->firstWhere('detail_type', 'initial')
                ?? $booking->bookingDetails->first();

            return $booking;
        });

        if (($filters['invoice_status'] ?? null) !== 'changed') {
            $paginator->setCollection($paginator->getCollection()
                ->filter(fn(Booking $booking) => $booking->sisa_tagihan > 0)
                ->values());
        }

        // Filter 'changed' masih dilakukan di PHP (hanya dari rows halaman saat ini)
        if (($filters['invoice_status'] ?? null) === 'changed') {
            $filtered = $paginator->getCollection()->filter(
                fn(Booking $booking) => (bool) ($booking->invoice_reconciliation['is_changed'] ?? false)
            )->values();
            $paginator->setCollection($filtered);
        }

        return $paginator;
    }

    public function invoices(array $filters = []): LengthAwarePaginator
    {
        $perPage = (int) ($filters['per_page'] ?? 15);

        return Invoice::query()
            ->with(['bookings.customer', 'payments.paymentAccount', 'payments.bookingPayments', 'creator', 'sentBy', 'mergedInto', 'childInvoices', 'voidRequester', 'voidApprover'])
            ->when($filters['tenant_id'] ?? null, fn($query, $tenantId) => $query->where('tenant_id', $tenantId))
            ->when($filters['branch_id'] ?? null, fn($query, $branchId) => $query->where('branch_id', $branchId))
            ->when($filters['kota'] ?? null, fn($query, $kota) => $query->whereHas('bookings', fn($q) => $q->where('kota', $kota)))
            ->when($filters['booking_id'] ?? null, fn($query, $bookingId) => $query->whereHas('bookings', fn($q) => $q->where('bookings.id', $bookingId)))
            ->when($filters['status'] ?? null, fn($query, $status) => $query->where('status', $status))
            ->when($filters['only_merged'] ?? null, fn($query) => $query->whereHas('childInvoices'))
            ->when($filters['exclude_paid'] ?? null, fn($query) => $query->where('status', '!=', 'paid'))
            ->when($filters['search'] ?? null, function ($query, $search) {
                $query->where(function ($q) use ($search) {
                    $q->where('invoice_number', 'like', "%{$search}%")
                        ->orWhereHas('bookings', fn($booking) => $booking->where('kode_booking', 'like', "%{$search}%")
                            ->orWhereHas('customer', fn($customer) => $customer->where('nama', 'like', "%{$search}%")));
                });
            })
            ->latest('generated_at')
            ->paginate($perPage);
    }

    public function invoiceReconciliation(Invoice $invoice): array
    {
        if ($invoice->is_manual_amount) {
            return [
                'current_total_amount' => (int) $invoice->total_amount,
                'difference_amount' => 0,
                'is_changed' => false,
                'change_type' => 'none',
                'requires_sent_confirmation' => false,
            ];
        }

        $amounts = $this->currentInvoiceBookingAmounts($invoice);
        $currentTotalAmount = (int) $amounts->sum();
        $differenceAmount = $currentTotalAmount - (int) $invoice->total_amount;

        return [
            'current_total_amount' => $currentTotalAmount,
            'difference_amount' => $differenceAmount,
            'is_changed' => $differenceAmount !== 0,
            'change_type' => $differenceAmount > 0 ? 'increase' : ($differenceAmount < 0 ? 'decrease' : 'none'),
            'requires_sent_confirmation' => $invoice->sent_at !== null && $differenceAmount !== 0,
        ];
    }

    public function refreshInvoiceAmount(Invoice $invoice, bool $confirmSentRevision = false): Invoice
    {
        return DB::transaction(function () use ($invoice, $confirmSentRevision) {
            $invoice = Invoice::query()
                ->with(['payments.paymentAccount', 'payments.bookingPayments'])
                ->lockForUpdate()
                ->findOrFail($invoice->id);

            if (! in_array($invoice->status, ['generated', 'partial_paid', 'paid'], true)) {
                throw new \InvalidArgumentException('Hanya invoice aktif atau lunas (dengan penambahan biaya) yang bisa diperbarui.');
            }

            if ($invoice->is_manual_amount) {
                throw new \InvalidArgumentException('Invoice dengan nominal manual tidak bisa di-refresh otomatis. Void dan buat invoice baru kalau nominalnya perlu diubah.');
            }

            if ($invoice->status === 'paid') {
                $amounts = $this->currentInvoiceBookingAmounts($invoice);
                if ((int) $amounts->sum() <= (int) $invoice->total_amount) {
                    throw new \InvalidArgumentException('Invoice sudah lunas tanpa penambahan biaya.');
                }
            }

            if ($invoice->sent_at && ! $confirmSentRevision) {
                throw new \InvalidArgumentException('Invoice sudah pernah dikirim. Konfirmasi revisi invoice diperlukan.');
            }

            $bookingIds = $invoice->bookings->pluck('id')->all();
            if ($bookingIds) {
                Booking::query()
                    ->whereIn('id', $bookingIds)
                    ->lockForUpdate()
                    ->get();

                $invoice->load(['payments.paymentAccount', 'payments.bookingPayments']);
            }

            $amounts = $this->currentInvoiceBookingAmounts($invoice);
            $totalAmount = (int) $amounts->sum();
            $paidAmount = $this->invoicePaidAmount($invoice);

            $amountBefore = (int) $invoice->total_amount;

            foreach ($amounts as $bookingId => $amount) {
                $invoice->bookings()->updateExistingPivot($bookingId, ['amount' => (int) $amount]);
            }

            $invoice->update([
                'total_amount' => $totalAmount,
                'paid_amount' => $paidAmount,
                'status' => $this->invoiceStatus($totalAmount, $paidAmount),
                'items_snapshot' => $this->computeInvoiceItems($invoice)->all(),
            ]);

            if ($amountBefore !== $totalAmount) {
                InvoiceHistory::create([
                    'invoice_id'    => $invoice->id,
                    'event_type'    => 'amended',
                    'description'   => 'Nominal invoice diperbarui',
                    'amount_before' => $amountBefore,
                    'amount_after'  => $totalAmount,
                    'created_by'    => auth()->id(),
                ]);
            }

            return $invoice->fresh(['bookings.customer', 'payments.paymentAccount', 'payments.bookingPayments']);
        });
    }

    public function paymentHistory(array $filters = []): array
    {
        $view = $filters['view'] ?? 'all';
        $latest = collect();
        $groups = collect();
        $latestMeta = $this->emptyPaginatorMeta((int) ($filters['latest_per_page'] ?? $filters['latest_limit'] ?? 20));
        $groupMeta = $this->emptyPaginatorMeta((int) ($filters['group_per_page'] ?? $filters['group_limit'] ?? 15));

        if (in_array($view, ['all', 'latest'], true)) {
            $latestPaginator = $this->latestPaymentHistory($filters);
            $latest = $latestPaginator->getCollection();
            $latestMeta = $this->paginatorMeta($latestPaginator);
        }

        if (in_array($view, ['all', 'group'], true)) {
            $groupPaginator = $this->groupedPaymentHistory($filters);
            $groups = $groupPaginator->getCollection();
            $groupMeta = $this->paginatorMeta($groupPaginator);
        }

        return [
            'latest' => $latest,
            'groups' => $groups,
            'meta' => [
                'latest' => $latestMeta,
                'groups' => $groupMeta,
            ],
        ];
    }

    private function latestPaymentHistory(array $filters): LengthAwarePaginator
    {
        $perPage = $this->historyPerPage($filters['latest_per_page'] ?? $filters['latest_limit'] ?? 20);
        $page = $this->historyPage($filters['latest_page'] ?? 1);

        $invoicePayments = Payment::query()
            ->selectRaw("'invoice' as source_type, payments.id as source_id, payments.paid_at, payments.created_at")
            ->when($filters['tenant_id'] ?? null, fn($query, $tenantId) => $query->whereHas('invoice', fn($invoice) => $invoice->where('tenant_id', $tenantId)))
            ->when($filters['branch_id'] ?? null, fn($query, $branchId) => $query->whereHas('invoice', fn($invoice) => $invoice->where('branch_id', $branchId)));

        $transactionPayments = BookingPayment::query()
            ->selectRaw("'transaction' as source_type, booking_payments.id as source_id, booking_payments.paid_at, booking_payments.created_at")
            ->whereNull('invoice_payment_id')
            ->when($filters['tenant_id'] ?? null, fn($query, $tenantId) => $query->whereHas('booking', fn($booking) => $booking->where('tenant_id', $tenantId)))
            ->when($filters['branch_id'] ?? null, fn($query, $branchId) => $query->whereHas('booking', fn($booking) => $booking->where('branch_id', $branchId)));

        $paginator = DB::query()
            ->fromSub($invoicePayments->toBase()->unionAll($transactionPayments->toBase()), 'payment_history')
            ->orderByDesc(DB::raw('COALESCE(paid_at, created_at)'))
            ->orderByDesc('source_id')
            ->paginate($perPage, ['*'], 'latest_page', $page);

        $rows = $paginator->getCollection();
        $invoiceIds = $rows->where('source_type', 'invoice')->pluck('source_id')->all();
        $transactionIds = $rows->where('source_type', 'transaction')->pluck('source_id')->all();

        $invoiceModels = Payment::query()
            ->with(['invoice.bookings.customer', 'paymentAccount', 'creator'])
            ->whereIn('id', $invoiceIds)
            ->get()
            ->keyBy('id');
        $transactionModels = BookingPayment::query()
            ->with(['booking.customer', 'paymentAccount', 'creator'])
            ->whereIn('id', $transactionIds)
            ->get()
            ->keyBy('id');

        $paginator->setCollection($rows
            ->map(function ($row) use ($invoiceModels, $transactionModels) {
                if ($row->source_type === 'invoice') {
                    $payment = $invoiceModels->get($row->source_id);

                    return $payment ? $this->formatInvoicePaymentHistory($payment) : null;
                }

                $payment = $transactionModels->get($row->source_id);

                return $payment ? $this->formatBookingPaymentHistory($payment) : null;
            })
            ->filter()
            ->values());

        return $paginator;
    }

    private function groupedPaymentHistory(array $filters): LengthAwarePaginator
    {
        $perPage = $this->historyPerPage($filters['group_per_page'] ?? $filters['group_limit'] ?? 15);
        $page = $this->historyPage($filters['group_page'] ?? 1);

        $paginator = BookingPayment::query()
            ->select('booking_id')
            ->selectRaw('SUM(CASE WHEN COALESCE(status, ?) != ? THEN amount ELSE 0 END) as total_amount', ['active', 'voided'])
            ->selectRaw('COUNT(*) as payment_count')
            ->selectRaw('MAX(paid_at) as latest_paid_at')
            ->with(['booking.customer'])
            ->when($filters['tenant_id'] ?? null, fn($query, $tenantId) => $query->whereHas('booking', fn($booking) => $booking->where('tenant_id', $tenantId)))
            ->when($filters['branch_id'] ?? null, fn($query, $branchId) => $query->whereHas('booking', fn($booking) => $booking->where('branch_id', $branchId)))
            ->groupBy('booking_id')
            ->orderByDesc('latest_paid_at')
            ->paginate($perPage, ['*'], 'group_page', $page);

        $bookingIds = $paginator->getCollection()->pluck('booking_id')->filter()->all();
        $paymentsByBooking = BookingPayment::query()
            ->with(['booking.customer', 'paymentAccount', 'creator', 'invoicePayment.invoice', 'invoicePayment.creator'])
            ->whereIn('booking_id', $bookingIds)
            ->latest('paid_at')
            ->get()
            ->groupBy('booking_id');

        $paginator->setCollection($paginator->getCollection()
            ->map(function (BookingPayment $summary) use ($paymentsByBooking) {
                $payments = $paymentsByBooking->get($summary->booking_id, collect());
                $booking = $summary->booking;

                return [
                    'booking_id' => $booking?->id,
                    'kode_booking' => $booking?->kode_booking,
                    'customer_name' => $booking?->customer?->nama,
                    'total_amount' => (int) $summary->total_amount,
                    'payment_count' => (int) $summary->payment_count,
                    'latest_paid_at' => $summary->latest_paid_at ? Carbon::parse($summary->latest_paid_at)->toISOString() : null,
                    'payments' => $payments
                        ->sortByDesc(fn(BookingPayment $payment) => $payment->paid_at?->timestamp ?? 0)
                        ->values()
                        ->map(fn(BookingPayment $payment) => $this->formatBookingPaymentHistory($payment))
                        ->values(),
                ];
            })
            ->values());

        return $paginator;
    }

    private function historyPerPage(int $perPage): int
    {
        return max(5, min(100, $perPage));
    }

    private function historyPage(int $page): int
    {
        return max(1, $page);
    }

    private function paginatorMeta(LengthAwarePaginator $paginator): array
    {
        return [
            'total' => $paginator->total(),
            'per_page' => $paginator->perPage(),
            'current_page' => $paginator->currentPage(),
            'last_page' => $paginator->lastPage(),
        ];
    }

    private function emptyPaginatorMeta(int $perPage): array
    {
        return [
            'total' => 0,
            'per_page' => $this->historyPerPage($perPage),
            'current_page' => 1,
            'last_page' => 1,
        ];
    }

    public function generateInvoice(array $bookingIds, int $branchId, int $tenantId, ?string $dueDate = null, ?string $termsAndConditions = null, array $amounts = [], ?string $paymentClassification = null): Invoice
    {
        return DB::transaction(function () use ($bookingIds, $branchId, $tenantId, $dueDate, $termsAndConditions, $amounts, $paymentClassification) {
            $bookings = Booking::query()
                ->with(['customer.member', 'bookingDetails.costs', 'payments', 'invoices'])
                ->whereIn('id', $bookingIds)
                ->where('branch_id', $branchId)
                ->lockForUpdate()
                ->get();

            if ($bookings->count() !== count(array_unique($bookingIds))) {
                throw new \InvalidArgumentException('Sebagian booking tidak ditemukan pada branch aktif.');
            }

            $cancelledBooking = $bookings->first(fn(Booking $booking) => $booking->status === 'batal');
            if ($cancelledBooking) {
                throw new \InvalidArgumentException("Booking {$cancelledBooking->kode_booking} sudah dibatalkan.");
            }

            $isManualAmount = false;
            $resolvedAmounts = $bookings->mapWithKeys(function (Booking $booking) use ($amounts, &$isManualAmount) {
                $autoAmount = $this->billingService->invoiceAmount($booking);
                $manualAmount = $amounts[$booking->id] ?? null;

                if ($manualAmount !== null) {
                    $manualAmount = (int) $manualAmount;
                    if ($manualAmount !== $autoAmount) {
                        $isManualAmount = true;
                    }

                    return [$booking->id => $manualAmount];
                }

                return [$booking->id => $autoAmount];
            });

            if ($resolvedAmounts->contains(fn($amount) => $amount <= 0)) {
                throw new \InvalidArgumentException('Semua booking harus memiliki tagihan.');
            }

            foreach ($bookings as $booking) {
                $requested = (int) $resolvedAmounts[$booking->id];
                $invoiceableBalance = $this->billingService->invoiceableBalance($booking);

                if ($requested > $invoiceableBalance) {
                    $formattedBalance = number_format($invoiceableBalance, 0, ',', '.');
                    throw new \InvalidArgumentException(
                        "Nominal invoice untuk booking {$booking->kode_booking} melebihi sisa yang bisa ditagih (maks Rp {$formattedBalance})."
                    );
                }
            }

            $paidAmount = (int) $bookings->sum(fn(Booking $booking) => $this->directBookingPayments($booking));

            $invoiceDueDate = $dueDate
                ? Carbon::parse($dueDate)
                : $this->defaultInvoiceDueDate($bookings);

            $invoice = Invoice::create([
                'tenant_id'            => $tenantId,
                'branch_id'            => $branchId,
                'invoice_number'       => $this->nextInvoiceNumber($branchId),
                'public_token'         => $this->newPublicToken(),
                'status'               => 'generated',
                'total_amount'         => (int) $resolvedAmounts->sum(),
                'is_manual_amount'     => $isManualAmount,
                'payment_classification' => $paymentClassification,
                'paid_amount'          => $paidAmount,
                'due_date'             => $invoiceDueDate,
                'terms_and_conditions' => $termsAndConditions,
                'generated_at'         => now(),
                'created_by'           => auth()->id(),
            ]);

            foreach ($resolvedAmounts as $bookingId => $amount) {
                $invoice->bookings()->attach($bookingId, ['amount' => (int) $amount]);
            }

            $invoice->update([
                'status' => $this->invoiceStatus((int) $invoice->total_amount, $paidAmount),
                'items_snapshot' => $this->computeInvoiceItems($invoice)->all(),
            ]);

            InvoiceHistory::create([
                'invoice_id'   => $invoice->id,
                'event_type'   => 'created',
                'description'  => 'Invoice dibuat',
                'amount_after' => (int) $invoice->total_amount,
                'created_by'   => auth()->id(),
            ]);

            return $invoice->load(['bookings.customer', 'payments.paymentAccount', 'payments.bookingPayments']);
        });
    }

    public function mergeInvoices(array $invoiceIds, int $branchId, int $tenantId, ?string $dueDate = null, ?string $termsAndConditions = null): Invoice
    {
        return DB::transaction(function () use ($invoiceIds, $branchId, $tenantId, $dueDate, $termsAndConditions) {
            $uniqueIds = array_values(array_unique($invoiceIds));

            if (count($uniqueIds) < 2) {
                throw new \InvalidArgumentException('Pilih minimal 2 invoice untuk digabungkan.');
            }

            $invoices = Invoice::query()
                ->whereIn('id', $uniqueIds)
                ->where('branch_id', $branchId)
                ->where('tenant_id', $tenantId)
                ->lockForUpdate()
                ->with(['bookings.payments', 'payments'])
                ->get();

            if ($invoices->count() !== count($uniqueIds)) {
                throw new \InvalidArgumentException('Sebagian invoice tidak ditemukan pada branch aktif.');
            }

            if (InvoiceInvoice::whereIn('parent_invoice_id', $uniqueIds)->exists()) {
                throw new \InvalidArgumentException('Salah satu invoice yang dipilih adalah invoice gabungan dan tidak bisa digabungkan lagi.');
            }

            $remainingAmounts = [];
            foreach ($invoices as $invoice) {
                if (! in_array($invoice->status, ['generated', 'partial_paid'], true)) {
                    throw new \InvalidArgumentException("Invoice {$invoice->invoice_number} berstatus {$invoice->status} dan tidak bisa digabungkan.");
                }

                if ($invoice->merged_into_id) {
                    throw new \InvalidArgumentException("Invoice {$invoice->invoice_number} sudah tergabung dalam invoice lain.");
                }

                $remaining = max(0, (int) $invoice->total_amount - $this->invoicePaidAmount($invoice));
                if ($remaining <= 0) {
                    throw new \InvalidArgumentException("Invoice {$invoice->invoice_number} sudah lunas, tidak ada sisa tagihan untuk digabungkan.");
                }

                $remainingAmounts[$invoice->id] = $remaining;
            }

            $totalAmount = array_sum($remainingAmounts);

            $invoiceDueDate = $dueDate
                ? Carbon::parse($dueDate)
                : $invoices->pluck('due_date')->filter()->map(fn($d) => Carbon::parse($d))->sortDesc()->first();

            $parent = Invoice::create([
                'tenant_id'            => $tenantId,
                'branch_id'            => $branchId,
                'invoice_number'       => $this->nextMergeInvoiceNumber($branchId),
                'public_token'         => $this->newPublicToken(),
                'status'               => 'generated',
                'total_amount'         => $totalAmount,
                'paid_amount'          => 0,
                'due_date'             => $invoiceDueDate,
                'terms_and_conditions' => $termsAndConditions,
                'generated_at'         => now(),
                'created_by'           => auth()->id(),
            ]);

            $items = [];
            foreach ($uniqueIds as $id) {
                $invoice = $invoices->firstWhere('id', $id);
                $amount = $remainingAmounts[$id];

                InvoiceInvoice::create([
                    'parent_invoice_id' => $parent->id,
                    'child_invoice_id'  => $id,
                    'amount'            => $amount,
                ]);

                $invoice->update(['merged_into_id' => $parent->id]);

                $items[] = [
                    'type'           => 'invoice',
                    'invoice_id'     => $id,
                    'invoice_number' => $invoice->invoice_number,
                    'description'    => $invoice->invoice_number,
                    'price'          => $amount,
                    'qty'            => 1,
                    'amount'         => $amount,
                ];

                InvoiceHistory::create([
                    'invoice_id'  => $id,
                    'event_type'  => 'merged_into',
                    'description' => "Digabung ke invoice {$parent->invoice_number}",
                    'created_by'  => auth()->id(),
                ]);
            }

            $parent->update(['items_snapshot' => $items]);

            InvoiceHistory::create([
                'invoice_id'   => $parent->id,
                'event_type'   => 'merged_created',
                'description'  => 'Invoice gabungan dibuat dari: ' . $invoices->pluck('invoice_number')->implode(', '),
                'amount_after' => $totalAmount,
                'created_by'   => auth()->id(),
            ]);

            return $parent->load(['childInvoices', 'payments.paymentAccount', 'payments.bookingPayments']);
        });
    }

    /**
     * Sinkronkan ulang nominal invoice booking ini (kalau ada) dengan data transaksi/biaya terbaru.
     * Dipanggil otomatis setiap kali booking di-handle, supaya invoice yang dibuat dari harga
     * dealing (saat masih follow_up/confirm) ikut diperbarui ke kalkulasi item-based yang riil.
     */
    public function refreshBookingInvoiceIfAny(Booking $booking): void
    {
        $invoice = $booking->invoices()
            ->where('invoices.status', '!=', 'void')
            ->latest('invoices.generated_at')
            ->first();

        if (! $invoice) {
            return;
        }

        try {
            $this->refreshInvoiceAmount($invoice, true);
        } catch (\InvalidArgumentException $e) {
            // Tidak ada nominal yang perlu diperbarui (misal sudah lunas tanpa penambahan biaya) — aman diabaikan.
        }
    }

    public function markSent(Invoice $invoice): Invoice
    {
        $invoice->update([
            'public_token' => $invoice->public_token ?: $this->newPublicToken(),
            'sent_at' => now(),
            'sent_by' => auth()->id(),
        ]);

        InvoiceHistory::create([
            'invoice_id'  => $invoice->id,
            'event_type'  => 'sent',
            'description' => 'Invoice dikirim ke pelanggan',
            'created_by'  => auth()->id(),
        ]);

        return $invoice->fresh(['bookings.customer', 'payments.paymentAccount', 'creator', 'sentBy']);
    }

    public function storePayment(Invoice $invoice, array $data): Invoice
    {
        return DB::transaction(function () use ($invoice, $data) {
            $invoice = Invoice::query()
                ->with(['bookings.bookingDetails.costs', 'bookings.payments.paymentAccount', 'payments.bookingPayments'])
                ->lockForUpdate()
                ->findOrFail($invoice->id);

            if ($invoice->status === 'void') {
                throw new \InvalidArgumentException('Invoice void tidak bisa dibayar.');
            }

            $remaining = max(0, (int) $invoice->total_amount - $this->invoicePaidAmount($invoice));
            if ((int) $data['amount'] > $remaining) {
                throw new \InvalidArgumentException('Nominal pembayaran melebihi sisa invoice.');
            }

            $payment = Payment::create([
                'invoice_id' => $invoice->id,
                'payment_account_id' => $data['payment_account_id'],
                'amount' => (int) $data['amount'],
                'paid_at' => \App\Helpers\DateHelper::parseDateWithCurrentTime($data['paid_at'] ?? null),
                'created_by' => auth()->id(),
            ]);

            $account = PaymentAccount::lockForUpdate()->findOrFail($payment->payment_account_id);
            $this->transactionService->applyDelta($account, (int) $payment->amount, [
                'type'           => 'invoice_payment_in',
                'amount'         => (int) $payment->amount,
                'description'    => "Pembayaran piutang invoice #{$invoice->invoice_number}",
                'created_by'     => auth()->id(),
                'transaction_at' => $payment->paid_at ?? now(),
            ]);

            $childPivots = InvoiceInvoice::where('parent_invoice_id', $invoice->id)->orderBy('id')->get();
            if ($childPivots->isNotEmpty()) {
                $this->syncInvoicePaymentToChildInvoices($invoice, $payment, $childPivots);
            } else {
                $this->syncInvoicePaymentToBookings($invoice, $payment);
            }

            $invoice->refresh();
            $invoice->load(['bookings.payments.paymentAccount', 'payments.bookingPayments']);
            $paidAmount = $this->invoicePaidAmount($invoice);
            $invoice->update([
                'paid_amount' => $paidAmount,
                'status' => $this->invoiceStatus((int) $invoice->total_amount, $paidAmount),
            ]);

            InvoiceHistory::create([
                'invoice_id'     => $invoice->id,
                'event_type'     => 'payment_received',
                'description'    => 'Pembayaran diterima',
                'payment_amount' => (int) $payment->amount,
                'created_by'     => auth()->id(),
            ]);

            return $invoice->fresh(['bookings.customer', 'payments.paymentAccount', 'payments.bookingPayments']);
        });
    }

    public function requestVoidInvoicePayment(Payment $payment, string $reason): Payment
    {
        if ($payment->status === 'voided') {
            throw ValidationException::withMessages([
                'payment' => ['Pembayaran ini sudah void.'],
            ]);
        }

        if ($payment->status === 'void_requested') {
            throw ValidationException::withMessages([
                'payment' => ['Request void pembayaran ini masih menunggu approval supervisor.'],
            ]);
        }

        $payment->update([
            'status' => 'void_requested',
            'void_reason' => $reason,
            'void_requested_by' => Auth::id(),
            'void_requested_at' => now(),
            'void_approved_by' => null,
            'void_approved_at' => null,
            'void_rejected_by' => null,
            'void_rejected_at' => null,
            'void_rejection_note' => null,
        ]);

        return $payment->fresh(['invoice', 'paymentAccount', 'creator', 'voidRequester', 'voidApprover', 'voidRejecter']);
    }

    public function approveVoidInvoicePayment(Payment $payment): Payment
    {
        return DB::transaction(function () use ($payment) {
            $payment = Payment::query()->lockForUpdate()->findOrFail($payment->id);

            if ($payment->status !== 'void_requested') {
                throw ValidationException::withMessages([
                    'payment' => ['Hanya pembayaran dengan status request void yang bisa di-approve.'],
                ]);
            }

            if ($payment->void_requested_by === Auth::id() && Auth::user()?->role !== 'superadmin') {
                throw ValidationException::withMessages([
                    'payment' => ['Request void harus di-ACC oleh supervisor lain.'],
                ]);
            }

            $payment->update([
                'status' => 'voided',
                'void_approved_by' => Auth::id(),
                'void_approved_at' => now(),
            ]);

            // Alokasi BookingPayment hasil pembayaran invoice ini ikut void,
            // supaya angka per-booking (cached_sisa_tagihan) tetap konsisten dengan invoice.paid_amount.
            BookingPayment::where('invoice_payment_id', $payment->id)->update(['status' => 'voided']);

            // Kalau payment ini berasal dari invoice gabungan (parent), void juga payment hasil
            // cascade-nya di tiap invoice anak, dan turun lagi ke BookingPayment masing-masing.
            $childPayments = Payment::where('parent_payment_id', $payment->id)->get();
            foreach ($childPayments as $childPayment) {
                $childPayment->update(['status' => 'voided']);

                BookingPayment::where('invoice_payment_id', $childPayment->id)->update(['status' => 'voided']);

                $childInvoice = Invoice::query()
                    ->with(['bookings.bookingDetails.costs', 'bookings.payments', 'payments'])
                    ->lockForUpdate()
                    ->find($childPayment->invoice_id);

                if (! $childInvoice) {
                    continue;
                }

                foreach ($childInvoice->bookings as $childBooking) {
                    $this->billingService->updateCachedSisaTagihan($childBooking);
                }

                $childInvoice->refresh();
                $childInvoice->load(['bookings.payments', 'payments']);
                $childPaidAmount = $this->invoicePaidAmount($childInvoice);
                $childInvoice->update([
                    'paid_amount' => $childPaidAmount,
                    'status' => $this->invoiceStatus((int) $childInvoice->total_amount, $childPaidAmount),
                ]);

                InvoiceHistory::create([
                    'invoice_id'     => $childInvoice->id,
                    'event_type'     => 'payment_voided',
                    'description'    => "Pembayaran di-void mengikuti void invoice gabungan {$payment->invoice->invoice_number}: " . $payment->void_reason,
                    'payment_amount' => (int) $childPayment->amount,
                    'created_by'     => Auth::id(),
                ]);
            }

            $invoice = Invoice::query()
                ->with(['bookings.bookingDetails.costs', 'bookings.payments', 'payments'])
                ->lockForUpdate()
                ->findOrFail($payment->invoice_id);

            foreach ($invoice->bookings as $booking) {
                $this->billingService->updateCachedSisaTagihan($booking);
            }

            $invoice->refresh();
            $invoice->load(['bookings.payments', 'payments']);
            $paidAmount = $this->invoicePaidAmount($invoice);
            $invoice->update([
                'paid_amount' => $paidAmount,
                'status' => $this->invoiceStatus((int) $invoice->total_amount, $paidAmount),
            ]);

            $account = PaymentAccount::lockForUpdate()->findOrFail($payment->payment_account_id);
            $this->transactionService->applyDelta($account, -(int) $payment->amount, [
                'type' => 'invoice_payment_void',
                'amount' => (int) $payment->amount,
                'description' => "Void pembayaran invoice #{$invoice->invoice_number}: " . $payment->void_reason,
                'created_by' => Auth::id(),
                'transaction_at' => now(),
            ]);

            InvoiceHistory::create([
                'invoice_id' => $invoice->id,
                'event_type' => 'payment_voided',
                'description' => 'Pembayaran di-void: ' . $payment->void_reason,
                'payment_amount' => (int) $payment->amount,
                'created_by' => Auth::id(),
            ]);

            return $payment->fresh(['invoice', 'paymentAccount', 'creator', 'voidRequester', 'voidApprover', 'voidRejecter']);
        });
    }

    public function rejectVoidInvoicePayment(Payment $payment, ?string $note = null): Payment
    {
        if ($payment->status !== 'void_requested') {
            throw ValidationException::withMessages([
                'payment' => ['Hanya pembayaran dengan status request void yang bisa ditolak.'],
            ]);
        }

        $payment->update([
            'status' => 'active',
            'void_rejected_by' => Auth::id(),
            'void_rejected_at' => now(),
            'void_rejection_note' => $note,
        ]);

        return $payment->fresh(['invoice', 'paymentAccount', 'creator', 'voidRequester', 'voidApprover', 'voidRejecter']);
    }

    public function requestVoidInvoice(Invoice $invoice, string $reason): Invoice
    {
        if ($invoice->status === 'void') {
            throw ValidationException::withMessages([
                'invoice' => ['Invoice ini sudah void.'],
            ]);
        }

        if ($invoice->status === 'void_requested') {
            throw ValidationException::withMessages([
                'invoice' => ['Request void invoice ini masih menunggu approval supervisor.'],
            ]);
        }

        if ($invoice->childInvoices()->exists()) {
            throw ValidationException::withMessages([
                'invoice' => ['Invoice ini punya invoice gabungan turunan. Void invoice gabungan tersebut dulu.'],
            ]);
        }

        $invoice->update([
            'status' => 'void_requested',
            'void_reason' => $reason,
            'void_requested_by' => Auth::id(),
            'void_requested_at' => now(),
            'void_approved_by' => null,
            'void_approved_at' => null,
            'void_rejected_by' => null,
            'void_rejected_at' => null,
            'void_rejection_note' => null,
        ]);

        return $invoice->fresh(['bookings.customer', 'payments.paymentAccount', 'voidRequester', 'voidApprover', 'voidRejecter']);
    }

    public function approveVoidInvoice(Invoice $invoice): Invoice
    {
        return DB::transaction(function () use ($invoice) {
            $invoice = Invoice::query()
                ->with(['bookings.bookingDetails.costs', 'bookings.payments', 'payments'])
                ->lockForUpdate()
                ->findOrFail($invoice->id);

            if ($invoice->status !== 'void_requested') {
                throw ValidationException::withMessages([
                    'invoice' => ['Hanya invoice dengan status request void yang bisa di-approve.'],
                ]);
            }

            if ($invoice->void_requested_by === Auth::id() && Auth::user()?->role !== 'superadmin') {
                throw ValidationException::withMessages([
                    'invoice' => ['Request void harus di-ACC oleh supervisor lain.'],
                ]);
            }

            foreach ($invoice->payments as $payment) {
                if (($payment->status ?? 'active') !== 'active') {
                    continue;
                }

                $payment->update([
                    'status' => 'voided',
                    'void_approved_by' => Auth::id(),
                    'void_approved_at' => now(),
                ]);

                BookingPayment::where('invoice_payment_id', $payment->id)->update(['status' => 'voided']);

                $account = PaymentAccount::lockForUpdate()->findOrFail($payment->payment_account_id);
                $this->transactionService->applyDelta($account, -(int) $payment->amount, [
                    'type' => 'invoice_void',
                    'amount' => (int) $payment->amount,
                    'description' => "Void invoice #{$invoice->invoice_number}: " . $invoice->void_reason,
                    'created_by' => Auth::id(),
                    'transaction_at' => now(),
                ]);

                InvoiceHistory::create([
                    'invoice_id'     => $invoice->id,
                    'event_type'     => 'payment_voided',
                    'description'    => 'Pembayaran di-void mengikuti void invoice: ' . $invoice->void_reason,
                    'payment_amount' => (int) $payment->amount,
                    'created_by'     => Auth::id(),
                ]);
            }

            foreach ($invoice->bookings as $booking) {
                $this->billingService->updateCachedSisaTagihan($booking);
            }

            $invoice->update([
                'status' => 'void',
                'paid_amount' => 0,
                'voided_at' => now(),
                'void_approved_by' => Auth::id(),
                'void_approved_at' => now(),
            ]);

            InvoiceHistory::create([
                'invoice_id'  => $invoice->id,
                'event_type'  => 'voided',
                'description' => 'Invoice di-void: ' . $invoice->void_reason,
                'created_by'  => Auth::id(),
            ]);

            return $invoice->fresh(['bookings.customer', 'payments.paymentAccount', 'voidRequester', 'voidApprover', 'voidRejecter']);
        });
    }

    public function rejectVoidInvoice(Invoice $invoice, ?string $note = null): Invoice
    {
        if ($invoice->status !== 'void_requested') {
            throw ValidationException::withMessages([
                'invoice' => ['Hanya invoice dengan status request void yang bisa ditolak.'],
            ]);
        }

        $paidAmount = $this->invoicePaidAmount($invoice);
        $invoice->update([
            'status' => $this->invoiceStatus((int) $invoice->total_amount, $paidAmount),
            'paid_amount' => $paidAmount,
            'void_rejected_by' => Auth::id(),
            'void_rejected_at' => now(),
            'void_rejection_note' => $note,
        ]);

        return $invoice->fresh(['bookings.customer', 'payments.paymentAccount', 'voidRequester', 'voidApprover', 'voidRejecter']);
    }

    public function publicInvoice(string $token): array
    {
        $invoice = Invoice::query()
            ->with(['branch', 'creator', 'bookings.customer', 'bookings.bookingDetails.unit', 'payments.paymentAccount', 'payments.bookingPayments', 'childInvoices'])
            ->where('public_token', $token)
            ->where('status', '!=', 'void')
            ->firstOrFail();

        $paymentAccounts = PaymentAccount::query()
            ->where('tenant_id', $invoice->tenant_id)
            ->where('branch_id', $invoice->branch_id)
            ->where('is_active', true)
            ->orderBy('nama_bank')
            ->get();

        return [$invoice, $paymentAccounts];
    }

    public function publicBookingProgress(string $token): Booking
    {
        return Booking::query()
            ->with(['customer', 'bookingDetails.costs', 'bookingDetails.unit'])
            ->where('public_token', $token)
            ->firstOrFail();
    }

    public function publicBookingInvoices(string $token): \Illuminate\Support\Collection
    {
        $booking = Booking::query()
            ->where('public_token', $token)
            ->firstOrFail();

        return $booking->invoices()
            ->where('invoices.status', '!=', 'void')
            ->with(['payments'])
            ->latest('invoices.generated_at')
            ->get();
    }

    public function bookingInvoiceHistories(Booking $booking): \Illuminate\Support\Collection
    {
        return $booking->invoices()
            ->with(['histories.actor'])
            ->get()
            ->flatMap(fn (Invoice $invoice) => $invoice->histories->map(fn ($h) => [
                'id'             => $h->id,
                'invoice_id'     => $invoice->id,
                'invoice_number' => $invoice->invoice_number,
                'event_type'     => $h->event_type,
                'description'    => $h->description,
                'amount_before'  => $h->amount_before,
                'amount_after'   => $h->amount_after,
                'payment_amount' => $h->payment_amount,
                'actor_name'     => $h->actor?->name,
                'created_at'     => $h->created_at,
            ]))
            ->sortByDesc('created_at')
            ->values();
    }

    private function syncInvoicePaymentToBookings(Invoice $invoice, Payment $payment): void
    {
        $remainingPayment = (int) $payment->amount;
        $previousPaymentIds = $invoice->payments()
            ->whereKeyNot($payment->id)
            ->pluck('id');

        foreach ($invoice->bookings as $booking) {
            if ($remainingPayment <= 0) {
                break;
            }

            $invoiceBookingAmount = (int) $booking->pivot->amount;
            $alreadyAllocated = $previousPaymentIds->isEmpty()
                ? 0
                : (int) BookingPayment::query()
                    ->where('booking_id', $booking->id)
                    ->whereIn('invoice_payment_id', $previousPaymentIds)
                    ->sum('amount');
            $alreadyAllocated += $this->directBookingPayments($booking);

            $bookingAllocationDue = max(0, $invoiceBookingAmount - $alreadyAllocated);
            $allocated = min($remainingPayment, $bookingAllocationDue);

            if ($allocated <= 0) {
                continue;
            }

            $bookingRemaining = $this->billingService->sisaTagihan($booking);

            BookingPayment::create([
                'booking_id' => $booking->id,
                'payment_account_id' => $payment->payment_account_id,
                'amount' => $allocated,
                'payment_type' => $invoice->payment_classification
                    ?? ($allocated >= $bookingRemaining ? 'pelunasan' : 'cicilan'),
                'status' => 'active',
                'catatan' => "Pembayaran invoice {$invoice->invoice_number}",
                'paid_at' => $payment->paid_at,
                'invoice_payment_id' => $payment->id,
                'created_by' => $payment->created_by,
            ]);

            $booking->unsetRelation('payments');
            $booking->load('bookingDetails.costs', 'payments');
            $this->billingService->updateCachedSisaTagihan($booking);

            $remainingPayment -= $allocated;
        }
    }

    /**
     * Cascade pembayaran invoice gabungan (parent) ke invoice anak, lalu invoice anak
     * di-cascade lagi ke booking lewat syncInvoicePaymentToBookings() yang sudah ada.
     */
    private function syncInvoicePaymentToChildInvoices(Invoice $parentInvoice, Payment $parentPayment, $childPivots): void
    {
        $remainingPayment = (int) $parentPayment->amount;
        $previousParentPaymentIds = $parentInvoice->payments()
            ->whereKeyNot($parentPayment->id)
            ->pluck('id');

        foreach ($childPivots as $pivot) {
            if ($remainingPayment <= 0) {
                break;
            }

            $childInvoice = Invoice::query()
                ->with(['bookings.bookingDetails.costs', 'bookings.payments.paymentAccount', 'payments.bookingPayments'])
                ->lockForUpdate()
                ->find($pivot->child_invoice_id);

            if (! $childInvoice) {
                continue;
            }

            $pivotAmount = (int) $pivot->amount;
            $alreadyAllocated = $previousParentPaymentIds->isEmpty()
                ? 0
                : (int) Payment::query()
                    ->where('invoice_id', $childInvoice->id)
                    ->whereIn('parent_payment_id', $previousParentPaymentIds)
                    ->sum('amount');

            $childAllocationDue = max(0, $pivotAmount - $alreadyAllocated);
            $allocated = min($remainingPayment, $childAllocationDue);

            if ($allocated <= 0) {
                continue;
            }

            $childPayment = Payment::create([
                'invoice_id' => $childInvoice->id,
                'parent_payment_id' => $parentPayment->id,
                'payment_account_id' => $parentPayment->payment_account_id,
                'amount' => $allocated,
                'paid_at' => $parentPayment->paid_at,
                'created_by' => $parentPayment->created_by,
            ]);

            InvoiceHistory::create([
                'invoice_id'     => $childInvoice->id,
                'event_type'     => 'payment_received',
                'description'    => "Alokasi pembayaran dari invoice gabungan {$parentInvoice->invoice_number}",
                'payment_amount' => $allocated,
                'created_by'     => $parentPayment->created_by,
            ]);

            $this->syncInvoicePaymentToBookings($childInvoice, $childPayment);

            $childInvoice->refresh();
            $childInvoice->load(['bookings.payments.paymentAccount', 'payments.bookingPayments']);
            $childPaidAmount = $this->invoicePaidAmount($childInvoice);
            $childInvoice->update([
                'paid_amount' => $childPaidAmount,
                'status' => $this->invoiceStatus((int) $childInvoice->total_amount, $childPaidAmount),
            ]);

            $remainingPayment -= $allocated;
        }
    }

    private function formatInvoicePaymentHistory(Payment $payment): array
    {
        $isCascaded = $payment->parent_payment_id !== null;

        return [
            'id' => 'invoice-' . $payment->id,
            'source' => $isCascaded ? 'invoice_allocation' : 'invoice',
            'source_label' => $isCascaded ? 'Alokasi Invoice Gabungan' : 'Pembayaran Invoice',
            'reference_number' => $payment->invoice?->invoice_number,
            'invoice_number' => $payment->invoice?->invoice_number,
            'transaction_codes' => $payment->invoice?->bookings?->pluck('kode_booking')->filter()->values() ?? collect(),
            'customer_names' => $payment->invoice?->bookings?->pluck('customer.nama')->filter()->unique()->values() ?? collect(),
            'payment_account_name' => $payment->paymentAccount
                ? trim($payment->paymentAccount->nama_bank . ' ' . $payment->paymentAccount->nomor_rekening)
                : null,
            'created_by_name' => $payment->creator?->name,
            'amount' => (int) $payment->amount,
            'status' => $payment->status ?? 'active',
            'payment_type' => null,
            'note' => null,
            'paid_at' => $payment->paid_at?->toISOString(),
            'created_at' => $payment->created_at?->toISOString(),
        ];
    }

    private function formatBookingPaymentHistory(BookingPayment $payment): array
    {
        $invoiceNumber = $payment->invoicePayment?->invoice?->invoice_number;

        return [
            'id' => 'transaction-' . $payment->id,
            'source' => $invoiceNumber ? 'invoice_allocation' : 'transaction',
            'source_label' => $invoiceNumber ? 'Alokasi Invoice' : 'Pembayaran Transaksi',
            'reference_number' => $invoiceNumber ?: $payment->booking?->kode_booking,
            'invoice_number' => $invoiceNumber,
            'transaction_codes' => collect([$payment->booking?->kode_booking])->filter()->values(),
            'customer_names' => collect([$payment->booking?->customer?->nama])->filter()->values(),
            'payment_account_name' => $payment->paymentAccount
                ? trim($payment->paymentAccount->nama_bank . ' ' . $payment->paymentAccount->nomor_rekening)
                : null,
            'created_by_name' => $payment->creator?->name ?? $payment->invoicePayment?->creator?->name,
            'amount' => (int) $payment->amount,
            'status' => $payment->status ?? 'active',
            'payment_type' => $payment->payment_type,
            'note' => $payment->catatan,
            'paid_at' => $payment->paid_at?->toISOString(),
            'created_at' => $payment->created_at?->toISOString(),
        ];
    }

    private function invoiceRemaining(Invoice $invoice): int
    {
        return max(0, (int) $invoice->total_amount - (int) $invoice->paid_amount);
    }

    public function invoicePaymentHistory(Invoice $invoice)
    {
        $invoice->loadMissing(['bookings.payments.paymentAccount', 'payments.paymentAccount']);

        $invoicePayments = collect($invoice->payments
            ->filter(fn(Payment $payment) => ($payment->status ?? 'active') !== 'voided')
            ->map(fn(Payment $payment) => [
                'id' => 'invoice-' . $payment->id,
                'source' => 'invoice',
                'payment_account_id' => $payment->payment_account_id,
                'payment_account_name' => $payment->paymentAccount
                    ? trim($payment->paymentAccount->nama_bank . ' ' . $payment->paymentAccount->nomor_rekening)
                    : null,
                'amount' => (int) $payment->amount,
                'paid_at' => $payment->paid_at?->toISOString(),
                'created_at' => $payment->created_at?->toISOString(),
            ])
            ->all());

        $directPayments = collect($invoice->bookings
            ->flatMap(fn(Booking $booking) => $booking->payments)
            ->filter(
                fn(BookingPayment $payment) => ($payment->status ?? 'active') !== 'voided'
                    && $payment->invoice_payment_id === null
            )
            ->map(fn(BookingPayment $payment) => [
                'id' => 'booking-' . $payment->id,
                'source' => 'booking',
                'payment_account_id' => $payment->payment_account_id,
                'payment_account_name' => $payment->paymentAccount
                    ? trim($payment->paymentAccount->nama_bank . ' ' . $payment->paymentAccount->nomor_rekening)
                    : null,
                'amount' => (int) $payment->amount,
                'paid_at' => $payment->paid_at?->toISOString(),
                'created_at' => $payment->created_at?->toISOString(),
            ])
            ->all());

        return $invoicePayments
            ->merge($directPayments)
            ->sortByDesc(fn($payment) => $payment['paid_at'] ?? $payment['created_at'])
            ->values();
    }

    public function invoiceItems(Invoice $invoice)
    {
        if (is_array($invoice->items_snapshot)) {
            return collect($invoice->items_snapshot);
        }

        return $this->computeInvoiceItems($invoice);
    }

    private function computeInvoiceItems(Invoice $invoice)
    {
        $invoice->loadMissing(['bookings.bookingDetails.unit', 'bookings.bookingDetails.costs']);

        return $invoice->bookings
            ->flatMap(function (Booking $booking) use ($invoice) {
                if ($invoice->payment_classification) {
                    return collect([$this->classifiedPaymentItem($invoice, $booking)]);
                }

                if ($this->billingService->usesDealingAmount($booking)) {
                    $detail = $booking->bookingDetails->whereNotIn('status', ['batal'])->first();
                    $unit = $detail?->unit;

                    return collect([[
                        'type' => 'rental',
                        'description' => $booking->kode_booking,
                        'booking_code' => $booking->kode_booking,
                        'vehicle_name' => trim(implode(' ', array_filter([$unit?->merk, $unit?->tipe]))) ?: ($detail?->unit_placeholder ?? null),
                        'vehicle_plate' => $unit?->no_polisi,
                        'rental_start_date' => $detail?->tgl_sewa,
                        'rental_end_date' => $detail?->tgl_kembali,
                        'price' => (int) $booking->harga_dealing,
                        'qty' => 1,
                        'amount' => (int) $booking->harga_dealing,
                    ]]);
                }

                return $booking->bookingDetails
                    ->whereNotIn('status', ['batal'])
                    ->flatMap(function ($detail) use ($booking) {
                        $unit = $detail->unit;
                        $vehicleName = trim(implode(' ', array_filter([$unit?->merk, $unit?->tipe]))) ?: ($detail->unit_placeholder ?? null);
                        $detailAmount = $this->detailBaseAmount($detail);
                        $items = collect();

                        if ($detailAmount !== 0) {
                            $items->push([
                                'type' => $detail->detail_type === 'extend' ? 'extend' : 'rental',
                                'description' => $detail->detail_type === 'extend' ? 'Extend' : $booking->kode_booking,
                                'booking_code' => $booking->kode_booking,
                                'vehicle_name' => $vehicleName,
                                'vehicle_plate' => $unit?->no_polisi,
                                'rental_start_date' => $detail->tgl_sewa,
                                'rental_end_date' => $detail->tgl_kembali,
                                'price' => (int) $detailAmount,
                                'qty' => 1,
                                'amount' => (int) $detailAmount,
                            ]);
                        }

                        $detail->costs
                            ->where('is_additional', true)
                            ->each(function ($cost) use ($items, $booking, $detail, $unit, $vehicleName) {
                                $amount = $cost->type === 'diskon' ? - ((int) $cost->amount) : (int) $cost->amount;
                                $items->push([
                                    'type' => 'additional_cost',
                                    'description' => 'Biaya Tambahan',
                                    'booking_code' => $booking->kode_booking,
                                    'label' => $cost->label,
                                    'note' => $cost->keterangan,
                                    'vehicle_name' => $vehicleName,
                                    'vehicle_plate' => $unit?->no_polisi,
                                    'rental_start_date' => $detail->tgl_sewa,
                                    'rental_end_date' => $detail->tgl_kembali,
                                    'price' => $amount,
                                    'qty' => 1,
                                    'amount' => $amount,
                                ]);
                            });

                        return $items;
                    });
            })
            ->values()
            ->when($invoice->is_manual_amount && ! $invoice->payment_classification, function ($items) use ($invoice) {
                $difference = (int) $invoice->total_amount - (int) $items->sum('amount');

                if ($difference === 0) {
                    return $items;
                }

                return $items->push([
                    'type' => 'adjustment',
                    'description' => 'Penyesuaian Nominal',
                    'price' => $difference,
                    'qty' => 1,
                    'amount' => $difference,
                ]);
            });
    }

    private function classifiedPaymentItem(Invoice $invoice, Booking $booking): array
    {
        $labels = [
            'dp' => 'Down Payment',
            'cicilan' => 'Cicilan',
            'pelunasan' => 'Pelunasan',
        ];
        $label = $labels[$invoice->payment_classification] ?? ucfirst($invoice->payment_classification);

        $detail = $booking->bookingDetails->firstWhere('status', 'aktif')
            ?? $booking->bookingDetails->whereNotIn('status', ['batal'])->first();
        $unit = $detail?->unit;
        $vehicleName = trim(implode(' ', array_filter([$unit?->merk, $unit?->tipe]))) ?: ($detail?->unit_placeholder ?? null);

        $amount = (int) $booking->pivot->amount;
        $totalNilaiSewa = $this->billingService->invoiceAmount($booking);
        $percentage = $totalNilaiSewa > 0 ? round($amount / $totalNilaiSewa * 100) : null;

        $description = $percentage !== null
            ? "{$label} ({$percentage}%) Sewa Mobil {$vehicleName}"
            : "{$label} Sewa Mobil {$vehicleName}";

        return [
            'type' => 'classified_payment',
            'description' => trim($description),
            'booking_code' => $booking->kode_booking,
            'vehicle_name' => $vehicleName,
            'vehicle_plate' => $unit?->no_polisi,
            'rental_start_date' => $detail?->tgl_sewa,
            'rental_end_date' => $detail?->tgl_kembali,
            'price' => $amount,
            'qty' => 1,
            'amount' => $amount,
        ];
    }

    public function contractInfo(Invoice $invoice): array
    {
        $invoice->loadMissing(['bookings.bookingDetails.costs', 'bookings.payments', 'payments']);
        $invoicePaymentIds = $invoice->payments->pluck('id');

        return $invoice->bookings->map(function (Booking $booking) use ($invoicePaymentIds) {
            $totalNilaiSewa = $this->billingService->invoiceAmount($booking);
            $tagihanSaatIni = (int) $booking->pivot->amount;

            $paidViaThisInvoice = $invoicePaymentIds->isEmpty() ? 0 : (int) $booking->payments
                ->filter(fn(BookingPayment $payment) =>
                    ($payment->status ?? 'active') !== 'voided'
                    && $invoicePaymentIds->contains($payment->invoice_payment_id))
                ->sum('amount');

            $telahDibayar = max(0, $this->billingService->paidAmount($booking) - $paidViaThisInvoice);
            $sisaPembayaranSelanjutnya = $this->billingService->invoiceableBalance($booking);

            return [
                'kode_booking' => $booking->kode_booking,
                'total_nilai_sewa' => $totalNilaiSewa,
                'telah_dibayar' => $telahDibayar,
                'tagihan_saat_ini' => $tagihanSaatIni,
                'sisa_pembayaran_selanjutnya' => $sisaPembayaranSelanjutnya,
            ];
        })->values()->all();
    }

    private function currentInvoiceBookingAmounts(Invoice $invoice)
    {
        $invoice->loadMissing(['bookings.bookingDetails.costs', 'bookings.payments.paymentAccount', 'payments.bookingPayments']);

        return $invoice->bookings->mapWithKeys(function (Booking $booking) {
            return [
                $booking->id => $this->billingService->invoiceAmount($booking),
            ];
        });
    }

    public function invoicePaidAmount(Invoice $invoice): int
    {
        $invoice->loadMissing(['bookings.payments', 'payments']);

        return (int) $invoice->payments
            ->filter(fn(Payment $payment) => ($payment->status ?? 'active') !== 'voided')
            ->sum('amount')
            + (int) $invoice->bookings->sum(fn(Booking $booking) => $this->directBookingPayments($booking));
    }

    private function directBookingPayments(Booking $booking): int
    {
        if (! $booking->relationLoaded('payments')) {
            $booking->load('payments');
        }

        return (int) $booking->payments
            ->filter(
                fn(BookingPayment $payment) => ($payment->status ?? 'active') !== 'voided'
                    && $payment->invoice_payment_id === null
            )
            ->sum('amount');
    }

    private function invoiceStatus(int $totalAmount, int $paidAmount): string
    {
        if ($paidAmount >= $totalAmount && $totalAmount > 0) {
            return 'paid';
        }

        return $paidAmount > 0 ? 'partial_paid' : 'generated';
    }

    private function detailBaseAmount(BookingDetail $detail): int
    {
        $duration = $detail->lama_sewa ?? 1;
        $costs = $detail->relationLoaded('costs') ? $detail->costs : collect();
        $regularCosts = $costs
            ->where('is_additional', false)
            ->sum(fn($cost) => $cost->type === 'diskon' ? - ((int) $cost->amount) : (int) $cost->amount);

        if ($detail->pricing_mode === 'all_in') {
            $regularCosts = $costs
                ->where('is_additional', false)
                ->where('type', 'diskon')
                ->sum(fn($cost) => - ((int) $cost->amount));

            return ((int) ($detail->harga_all_in ?? 0) * $duration) + $regularCosts;
        }

        return $this->billingService->detailRentalSubtotal($detail) + $regularCosts;
    }

    private function nextInvoiceNumber(int $branchId): string
    {
        $prefix = 'INV-' . date('Ym') . '-' . str_pad((string) $branchId, 2, '0', STR_PAD_LEFT) . '-';
        $lastInvoice = Invoice::where('branch_id', $branchId)
            ->where('invoice_number', 'like', $prefix . '%')
            ->orderByDesc('invoice_number')
            ->first();

        $next = $lastInvoice ? ((int) substr($lastInvoice->invoice_number, -5)) + 1 : 1;

        return $prefix . str_pad((string) $next, 5, '0', STR_PAD_LEFT);
    }

    private function nextMergeInvoiceNumber(int $branchId): string
    {
        $prefix = 'SOA-' . date('Ym') . '-' . str_pad((string) $branchId, 2, '0', STR_PAD_LEFT) . '-';
        $lastInvoice = Invoice::where('branch_id', $branchId)
            ->where('invoice_number', 'like', $prefix . '%')
            ->orderByDesc('invoice_number')
            ->first();

        $next = $lastInvoice ? ((int) substr($lastInvoice->invoice_number, -5)) + 1 : 1;

        return $prefix . str_pad((string) $next, 5, '0', STR_PAD_LEFT);
    }

    private function newPublicToken(): string
    {
        do {
            $token = Str::random(48);
        } while (Invoice::where('public_token', $token)->exists());

        return $token;
    }

    private function defaultInvoiceDueDate($bookings): ?Carbon
    {
        return $bookings
            ->map(function (Booking $booking) {
                if (! $booking->due_date) {
                    $booking->update([
                        'due_date' => $this->billingService->calculateDueDate($booking),
                    ]);
                    $booking->refresh();
                }

                return $booking->due_date ? Carbon::parse($booking->due_date) : null;
            })
            ->filter()
            ->sortDesc()
            ->first();
    }
}
