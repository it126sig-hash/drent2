<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\RejectCancelExtendRequest;
use App\Http\Requests\RequestCancelExtendRequest;
use App\Http\Requests\StoreBookingDetailRequest;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use App\Services\BookingBillingService;
use App\Services\BookingModificationService;
use App\Services\BookingService;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use App\Http\Requests\UpdateBookingDetailRequest;
use App\Models\BookingDetail;
use App\Services\RentToRentService;

class BookingDetailController extends Controller
{
    use AuthorizesRequests;

    protected array $bookingRelations = [
        'customer', 'bookingDetails.unit.rentalOwner', 'bookingDetails.driver',
        'bookingDetails.costs.costType', 'payments', 'refunds',
    ];

    public function __construct(
        protected BookingService $bookingService,
        protected BookingBillingService $billingService,
        protected BookingModificationService $modificationService,
    ) {}

    public function store(StoreBookingDetailRequest $request, Booking $booking)
    {
        $this->authorize('update', $booking);
        
        $this->bookingService->assignDetail($booking, $request->validated());
        
        // Harga/costs baru ditambahkan — sync cache sisa tagihan
        $booking->load(['bookingDetails.costs', 'payments']);
        $this->billingService->updateCachedSisaTagihan($booking);
        
        return new BookingResource($booking->load(['customer', 'bookingDetails.unit.rentalOwner', 'bookingDetails.driver', 'bookingDetails.costs.costType', 'payments', 'refunds']));
    }

    public function update(UpdateBookingDetailRequest $request, BookingDetail $bookingDetail)
    {
        $this->authorize('update', $bookingDetail->booking);

        if (
            in_array($bookingDetail->detail_type, ['extend', 'rolling'], true)
            && (
                in_array($bookingDetail->status, ['selesai', 'batal', 'cancelled', 'completed'], true)
                || in_array($bookingDetail->booking->status, ['selesai', 'batal', 'cancelled', 'completed'], true)
            )
        ) {
            abort(422, 'Transaksi yang sudah selesai atau batal tidak bisa diedit.');
        }

        $bookingDetail->update([
            'unit_id' => $request->unit_id,
            'unit_placeholder' => null,
            'driver_id' => $request->driver_id,
            'tgl_sewa' => \Carbon\Carbon::parse($request->tgl_sewa)->format('Y-m-d H:i:s'),
            'tgl_kembali' => \Carbon\Carbon::parse($request->tgl_kembali)->format('Y-m-d H:i:s'),
            'harga_mobil' => $request->harga_mobil,
            'diskon_mobil' => $request->diskon_mobil ?? 0,
            'lama_sewa' => $request->lama_sewa,
            'paket_sewa' => $request->paket_sewa,
            'pricing_mode' => $request->pricing_mode,
            'pricing_package_id' => $request->pricing_package_id,
            'harga_all_in' => $request->harga_all_in,
        ]);

        $bookingDetail->costs()->delete();
        foreach ($request->input('costs', []) as $costData) {
            $bookingDetail->costs()->create([
                'cost_type_id' => $costData['cost_type_id'] ?? null,
                'type' => $costData['type'] ?? 'biaya',
                'label' => $costData['label'],
                'amount' => $costData['amount'],
                'keterangan' => $costData['keterangan'] ?? null,
                'is_additional' => (bool) ($costData['is_additional'] ?? false),
            ]);
        }

        app(RentToRentService::class)->syncDetail($bookingDetail->fresh(['booking', 'unit.rentalOwner']));

        // Harga/costs berubah — sync cache sisa tagihan
        $booking = $bookingDetail->booking->load(['bookingDetails.costs', 'payments']);
        $this->billingService->updateCachedSisaTagihan($booking);

        return new BookingResource($bookingDetail->booking->load(['customer', 'bookingDetails.unit.rentalOwner', 'bookingDetails.driver', 'bookingDetails.costs.costType', 'payments', 'refunds']));
    }

    public function requestCancelExtend(RequestCancelExtendRequest $request, BookingDetail $bookingDetail)
    {
        $this->authorize('requestCancelExtend', $bookingDetail->booking);
        $this->modificationService->requestCancelExtend($bookingDetail, $request->validated()['reason']);

        return new BookingResource($bookingDetail->booking->load($this->bookingRelations));
    }

    public function approveCancelExtend(BookingDetail $bookingDetail)
    {
        $this->authorize('approveCancelExtend', $bookingDetail->booking);
        $this->modificationService->approveCancelExtend($bookingDetail);

        return new BookingResource($bookingDetail->booking->load($this->bookingRelations));
    }

    public function rejectCancelExtend(RejectCancelExtendRequest $request, BookingDetail $bookingDetail)
    {
        $this->authorize('approveCancelExtend', $bookingDetail->booking);
        $this->modificationService->rejectCancelExtend($bookingDetail, $request->validated()['rejection_note'] ?? null);

        return new BookingResource($bookingDetail->booking->load($this->bookingRelations));
    }
}
