<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BookingDetail extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'booking_id',
        'unit_id',
        'unit_placeholder',
        'driver_id',
        'tgl_sewa',
        'tgl_kembali',
        'harga_mobil',
        'modal_mobil',
        'diskon_mobil',
        'lama_sewa',
        'paket_sewa',
        'pricing_mode',
        'pricing_package_id',
        'harga_all_in',
        'detail_type',
        'status',
        'created_by',
        'cancel_extend_status',
        'cancel_extend_reason',
        'cancel_extend_requested_by',
        'cancel_extend_requested_at',
        'cancel_extend_approved_by',
        'cancel_extend_approved_at',
        'cancel_extend_rejected_by',
        'cancel_extend_rejected_at',
        'cancel_extend_rejection_note',
    ];

    protected $casts = [
        'lama_sewa' => 'integer',
        'harga_all_in' => 'integer',
        'harga_mobil' => 'integer',
        'modal_mobil' => 'integer',
        'diskon_mobil' => 'integer',
    ];

    // TODO: konfirmasi strategi arsip (soft-delete vs tabel terpisah vs is_archived flag)
    // Keputusan ini belum final per 2026-05-10.

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function unit()
    {
        return $this->belongsTo(Unit::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function driver()
    {
        return $this->belongsTo(Driver::class);
    }

    public function costs()
    {
        return $this->hasMany(BookingCost::class);
    }

    public function pricingPackage()
    {
        return $this->belongsTo(PricingPackage::class);
    }

    public function operationalFunds()
    {
        return $this->hasMany(DriverOperationalFund::class);
    }

    public function operationalExpenses()
    {
        return $this->hasMany(DriverOperationalExpense::class);
    }

    public function fleetCardFunds()
    {
        return $this->hasMany(FleetCardFund::class);
    }

    public function fleetCardExpenses()
    {
        return $this->hasMany(FleetCardExpense::class);
    }

    public function rentToRentDebt()
    {
        return $this->hasOne(RentToRentDebt::class);
    }

    public function cancelExtendRequester()
    {
        return $this->belongsTo(User::class, 'cancel_extend_requested_by');
    }

    public function cancelExtendApprover()
    {
        return $this->belongsTo(User::class, 'cancel_extend_approved_by');
    }

    public function cancelExtendRejecter()
    {
        return $this->belongsTo(User::class, 'cancel_extend_rejected_by');
    }
}
