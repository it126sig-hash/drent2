<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FleetCardFund extends Model
{
    protected $fillable = [
        'tenant_id',
        'branch_id',
        'fleet_card_id',
        'booking_id',
        'booking_detail_id',
        'driver_id',
        'payment_account_id',
        'amount',
        'paid_at',
        'recipient_destination',
        'notes',
        'status',
        'accepted_at',
        'accepted_by',
        'created_by',
        'cancelled_by',
        'closed_at',
        'closed_by',
        'close_note',
        'status_before_void',
        'void_reason',
        'void_requested_by',
        'void_requested_at',
        'void_approved_by',
        'void_approved_at',
        'void_rejected_by',
        'void_rejected_at',
        'void_rejection_note',
    ];

    protected $casts = [
        'amount' => 'integer',
        'paid_at' => 'datetime',
        'accepted_at' => 'datetime',
        'closed_at' => 'datetime',
        'void_requested_at' => 'datetime',
        'void_approved_at' => 'datetime',
        'void_rejected_at' => 'datetime',
    ];

    public function fleetCard()
    {
        return $this->belongsTo(FleetCard::class);
    }

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function bookingDetail()
    {
        return $this->belongsTo(BookingDetail::class);
    }

    public function driver()
    {
        return $this->belongsTo(Driver::class);
    }

    public function paymentAccount()
    {
        return $this->belongsTo(PaymentAccount::class);
    }

    public function items()
    {
        return $this->hasMany(FleetCardFundItem::class);
    }

    public function expenses()
    {
        return $this->hasMany(FleetCardExpense::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function acceptedBy()
    {
        return $this->belongsTo(User::class, 'accepted_by');
    }

    public function closedBy()
    {
        return $this->belongsTo(User::class, 'closed_by');
    }

    public function voidRequester()
    {
        return $this->belongsTo(User::class, 'void_requested_by');
    }

    public function voidApprover()
    {
        return $this->belongsTo(User::class, 'void_approved_by');
    }

    public function voidRejecter()
    {
        return $this->belongsTo(User::class, 'void_rejected_by');
    }

    public function approvedExpenseTotal(): int
    {
        $expenses = $this->relationLoaded('expenses')
            ? $this->expenses
            : $this->expenses()->get();

        return (int) $expenses
            ->whereIn('status', ['approved', 'void_requested'])
            ->where('type', 'expense')
            ->sum('amount');
    }

    public function approvedReturnTotal(): int
    {
        $expenses = $this->relationLoaded('expenses')
            ? $this->expenses
            : $this->expenses()->get();

        return (int) $expenses
            ->whereIn('status', ['approved', 'void_requested'])
            ->where('type', 'return')
            ->sum('amount');
    }

    public function pendingReviewCount(): int
    {
        $expenses = $this->relationLoaded('expenses')
            ? $this->expenses
            : $this->expenses()->get();

        return $expenses->where('status', 'submitted')->count();
    }

    public function pendingDriverReviewCount(): int
    {
        $expenses = $this->relationLoaded('expenses')
            ? $this->expenses
            : $this->expenses()->get();

        return $expenses
            ->where('status', 'submitted')
            ->where('source', 'driver')
            ->count();
    }

    /**
     * Saldo riil yang bisa dipakai sekarang hidup di kartu (kumulatif lintas fund/booking),
     * bukan di amount fund ini sendiri.
     */
    public function remainingAmount(): int
    {
        return (int) ($this->fleetCard?->saldo ?? 0);
    }
}
