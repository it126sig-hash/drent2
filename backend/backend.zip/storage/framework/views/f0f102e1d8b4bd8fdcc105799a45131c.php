<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($invoice->invoice_number); ?></title>
    <style>
        @page {
            size: A4;
            margin: 0;
        }

        * {
            box-sizing: border-box;
        }

        html, body {
            margin: 0;
            padding: 0;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #1f2937;
            background: #ffffff;
        }

        .page {
            position: relative;
            width: 100%;
            padding-bottom: 48px;
        }

        /* TOP BAR */
        .top-bar {
            background-color: #1f2937;
            color: #ffffff;
            padding: 32px 40px;
        }

        .top-bar-table {
            width: 100%;
            border-collapse: collapse;
        }

        .top-bar-table td {
            vertical-align: middle;
        }

        .brand-cell {
            text-align: left;
        }

        .brand-header-table {
            width: auto;
            border-collapse: collapse;
            margin-bottom: 8px;
        }

        .brand-header-table td {
            vertical-align: middle;
            padding: 0;
        }

        .brand-logo {
            background: #ffffff;
            border-radius: 4px;
            display: block;
        }

        .brand-name {
            font-size: 22px;
            font-weight: 700;
            line-height: 1.1;
            letter-spacing: 0.5px;
        }

        .brand-tagline {
            font-size: 9px;
            color: #cbd5e1;
            letter-spacing: 1px;
            margin-top: 4px;
        }

        .branch-contact {
            font-size: 10px;
            color: #cbd5e1;
            margin-top: 6px;
            line-height: 1.6;
        }

        .invoice-title-cell {
            text-align: right;
            vertical-align: top;
        }

        .invoice-title {
            font-size: 32px;
            font-weight: 700;
            color: #E5534B;
            letter-spacing: 2px;
        }

        .invoice-title-meta {
            font-size: 10px;
            color: #cbd5e1;
            margin-top: 4px;
        }

        /* RED LINE */
        .red-line {
            height: 8px;
            background-color: #E5534B;
            line-height: 0;
            font-size: 0;
        }

        /* META BAR */
        .meta-bar {
            background-color: #272C3F;
            color: #ffffff;
            padding: 24px 40px;
        }

        .meta-bar-table {
            width: 100%;
            border-collapse: collapse;
        }

        .meta-bar-table td {
            vertical-align: top;
        }

        .billed-to-cell {
            width: 60%;
            padding-right: 20px;
        }

        .invoice-details-cell {
            width: 40%;
        }

        .billed-to-title {
            font-size: 14px;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 6px;
        }

        .customer-name {
            font-size: 14px;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 4px;
        }

        .customer-line {
            font-size: 11px;
            color: #cbd5e1;
            line-height: 1.5;
        }

        .invoice-detail-row {
            font-size: 12px;
            line-height: 1.7;
        }

        .invoice-detail-row .label {
            font-weight: 700;
            color: #ffffff;
        }

        .invoice-detail-row .value {
            color: #ffffff;
        }

        /* TABLE */
        .items-section {
            padding: 24px 40px 0 40px;
        }

        .items-table {
            width: 100%;
            border-collapse: collapse;
        }

        .items-table thead th {
            background-color: #EAF0EC;
            color: #1f2937;
            font-weight: 700;
            font-size: 12px;
            padding: 10px 8px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }

        .items-table thead th.center {
            text-align: center;
        }

        .items-table thead th.right {
            text-align: right;
        }

        .items-table tbody td {
            padding: 12px 8px;
            font-size: 11px;
            border-bottom: 1px solid #e5e7eb;
            vertical-align: top;
        }

        .items-table tbody td.center {
            text-align: center;
        }

        .items-table tbody td.right {
            text-align: right;
        }

        .item-meta {
            color: #6b7280;
            font-size: 10px;
            margin-top: 2px;
            line-height: 1.4;
        }

        .mono {
            font-family: DejaVu Sans Mono, monospace;
        }

        /* BOTTOM SECTION */
        .bottom-section {
            padding: 28px 40px 0 40px;
        }

        .bottom-table {
            width: 100%;
            border-collapse: collapse;
        }

        .bottom-table > tbody > tr > td {
            vertical-align: top;
        }

        .bottom-left-cell {
            width: 60%;
            padding-right: 20px;
        }

        .bottom-right-cell {
            width: 40%;
            padding-left: 10px;
        }

        .thank-you {
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 12px;
        }

        .section-label {
            color: #6b7280;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
            text-transform: uppercase;
        }

        .payment-title {
            font-size: 13px;
            font-weight: 700;
            margin-top: 4px;
            margin-bottom: 8px;
        }

        .accounts-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 18px;
        }

        .accounts-table td {
            border: 1px solid #e5e7eb;
            background-color: #f9fafb;
            border-radius: 4px;
            padding: 8px;
            width: 50%;
            vertical-align: top;
            font-size: 11px;
        }

        .account-bank {
            font-weight: 700;
            color: #1f2937;
            font-size: 11px;
        }

        .account-number {
            font-family: DejaVu Sans Mono, monospace;
            font-weight: 700;
        }

        .account-name {
            color: #6b7280;
            margin-top: 2px;
        }

        .terms-title {
            font-size: 13px;
            font-weight: 700;
            margin-top: 8px;
            margin-bottom: 6px;
        }

        .terms-text {
            font-size: 10px;
            color: #6b7280;
            line-height: 1.5;
            margin: 0;
        }

        .terms-text p {
            margin: 0 0 4px;
            font-size: 10px;
            color: #6b7280;
            line-height: 1.5;
        }

        .terms-text p:last-child {
            margin-bottom: 0;
        }

        .terms-text ul,
        .terms-text ol {
            margin: 0 0 4px;
            padding-left: 18px;
        }

        .terms-text li {
            margin-bottom: 2px;
        }

        /* TOTALS */
        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }

        .totals-table td {
            padding: 7px 0;
            font-size: 12px;
            font-weight: 600;
            vertical-align: middle;
        }

        .totals-table td.right {
            text-align: right;
            font-family: DejaVu Sans Mono, monospace;
        }

        .totals-table tr.grand-total td {
            border-top: 1px solid #1f2937;
            border-bottom: 1px solid #1f2937;
            font-size: 14px;
            padding: 10px 0;
        }

        .status-pill {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .status-pill.success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .status-pill.info {
            background-color: #dbeafe;
            color: #1e40af;
        }

        .status-pill.warn {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-pill.danger {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .signature-section {
            margin-top: 50px;
            text-align: center;
            width: 150px;
            margin-left: auto;
        }

        .signature-img {
            margin-bottom: 4px;
            display: block;
        }

        .signature-line {
            border-bottom: 1px solid #1f2937;
            height: 1px;
            margin-bottom: 6px;
        }

        .signature-text {
            font-size: 12px;
            font-weight: 700;
            word-break: break-word;
        }

        .signature-caption {
            font-size: 9px;
            font-weight: 500;
            color: #6b7280;
            letter-spacing: 0.4px;
            text-transform: uppercase;
            margin-top: 2px;
        }

        .empty-text {
            color: #6b7280;
            font-size: 11px;
            font-style: italic;
        }

        /* FOOTER BAND */
        .footer-band {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 24px;
            background-color: #272C3F;
        }
    </style>
</head>
<body>
    <div class="page">
        
        <div class="top-bar">
            <table class="top-bar-table">
                <tr>
                    <td class="brand-cell">
                        <table class="brand-header-table">
                            <tr>
                                <?php if($branchLogoBase64): ?>
                                <td style="padding-right: 12px; vertical-align: middle;">
                                    <img src="<?php echo e($branchLogoBase64); ?>" class="brand-logo" style="width:<?php echo e($branchLogoWidth); ?>px; height:<?php echo e($branchLogoHeight); ?>px;" alt="Logo" />
                                </td>
                                <?php endif; ?>
                                <td style="vertical-align: middle;">
                                    <div class="brand-name"><?php echo e($branchName); ?></div>
                                    <div class="brand-tagline">CAR RENTAL SYSTEM</div>
                                </td>
                            </tr>
                        </table>
                        <?php if($branchAddress || $branchPhone || $branchEmail): ?>
                        <div class="branch-contact">
                            <?php if($branchAddress): ?><span><?php echo e($branchAddress); ?></span><?php endif; ?>
                            <?php if($branchPhone): ?> &nbsp;&bull;&nbsp; <span><?php echo e($branchPhone); ?></span><?php endif; ?>
                            <?php if($branchEmail): ?> &nbsp;&bull;&nbsp; <span><?php echo e($branchEmail); ?></span><?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </td>
                    <td class="invoice-title-cell">
                        <div class="invoice-title">INVOICE</div>
                        <div class="invoice-title-meta">Generated: <?php echo e($generatedDate); ?></div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="red-line">&nbsp;</div>

        
        <div class="meta-bar">
            <table class="meta-bar-table">
                <tr>
                    <td class="billed-to-cell">
                        <div class="billed-to-title">Billed to:</div>
                        <div class="customer-name"><?php echo e($customerName); ?></div>
                        <?php $__currentLoopData = $customerAddressLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="customer-line"><?php echo e($line); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $customerContactLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="customer-line"><?php echo e($line); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(empty($customerAddressLines) && empty($customerContactLines)): ?>
                            <div class="customer-line">Terima kasih telah menggunakan layanan penyewaan kami.</div>
                        <?php endif; ?>
                    </td>
                    <td class="invoice-details-cell">
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr class="invoice-detail-row">
                                <td class="label">Invoice#</td>
                                <td class="value mono" style="text-align: right;"><?php echo e($invoice->invoice_number); ?></td>
                            </tr>
                            <tr class="invoice-detail-row">
                                <td class="label">Date:</td>
                                <td class="value mono" style="text-align: right;"><?php echo e($invoiceDate); ?></td>
                            </tr>
                            <tr class="invoice-detail-row">
                                <td class="label">Due Date:</td>
                                <td class="value mono" style="text-align: right;"><?php echo e($dueDate); ?></td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>

        
        <div class="items-section">
            <table class="items-table">
                <thead>
                    <tr>
                        <th class="center" style="width: 8%;">SL.</th>
                        <th style="width: 50%;">Item Description</th>
                        <th class="right" style="width: 16%;">Price</th>
                        <th class="center" style="width: 10%;">Qty.</th>
                        <th class="right" style="width: 16%;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="center"><?php echo e($index + 1); ?></td>
                            <td>
                                <div>
                                    <strong><?php echo e($item['description'] ?: ($item['booking_code'] ?? 'Rental Service')); ?>:</strong>
                                    <?php if(!empty($item['vehicle_name']) || !empty($item['vehicle_plate'])): ?>
                                        <span style="font-weight: 600;"><?php echo e($item['vehicle_name'] ?: 'Rental Service'); ?></span>
                                        <?php if(!empty($item['vehicle_plate'])): ?>
                                            <span class="mono">(<?php echo e($item['vehicle_plate']); ?>)</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <?php if(!empty($item['label'])): ?>
                                    <div class="item-meta">
                                        <?php echo e($item['label']); ?><?php if(!empty($item['note'])): ?> : <?php echo e($item['note']); ?><?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <?php if(!empty($item['rental_start_date']) || !empty($item['rental_end_date'])): ?>
                                    <div class="item-meta">
                                        <?php echo e($formatDate($item['rental_start_date'] ?? null)); ?> - <?php echo e($formatDate($item['rental_end_date'] ?? null)); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="right mono"><?php echo e($formatCurrency($item['price'] ?? $item['amount'] ?? 0)); ?></td>
                            <td class="center mono"><?php echo e($item['qty'] ?? 1); ?></td>
                            <td class="right mono"><strong><?php echo e($formatCurrency($item['amount'] ?? 0)); ?></strong></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="center empty-text">Belum ada detail item invoice.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="bottom-section">
            <table class="bottom-table">
                <tr>
                    
                    <td class="bottom-left-cell">
                        <div class="thank-you">Thank you for your business</div>

                        <div class="payment-title">Payment Info:</div>
                        <div class="section-label">Nomor Rekening</div>
                        <?php if(count($paymentAccounts)): ?>
                            <table class="accounts-table">
                                <?php $rows = array_chunk($paymentAccounts, 2); ?>
                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td>
                                                <div class="account-bank"><?php echo e($account['nama_bank']); ?>: <span class="account-number"><?php echo e($account['nomor_rekening']); ?></span></div>
                                                <div class="account-name"><?php echo e($account['atas_nama']); ?></div>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($row) === 1): ?>
                                            <td style="border: none; background: transparent;"></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php else: ?>
                            <div class="empty-text" style="margin-bottom: 16px;">Tidak ada informasi rekening pembayaran.</div>
                        <?php endif; ?>

                        <div class="terms-title">Terms &amp; Conditions</div>
                        <?php
                            $plainTerms = trim(strip_tags($termsAndConditions ?? ''));
                            $plainTerms = str_replace('&nbsp;', ' ', $plainTerms);
                        ?>
                        <?php if(!empty($plainTerms)): ?>
                            <div class="terms-text"><?php echo $termsAndConditions; ?></div>
                        <?php else: ?>
                            <p class="terms-text">Harap lakukan pembayaran sebelum tanggal jatuh tempo. Keterlambatan dapat dikenakan denda sesuai dengan ketentuan penyewaan. Terima kasih telah mempercayai DRENT.</p>
                        <?php endif; ?>
                    </td>

                    
                    <td class="bottom-right-cell">
                        <table class="totals-table">
                            <tr>
                                <td>Sub Total:</td>
                                <td class="right"><?php echo e($formatCurrency($invoice->total_amount)); ?></td>
                            </tr>
                            <tr>
                                <td>Paid:</td>
                                <td class="right"><?php echo e($formatCurrency($paidAmount)); ?></td>
                            </tr>
                            <tr>
                                <td>Status:</td>
                                <td class="right">
                                    <span class="status-pill <?php echo e($statusSeverity); ?>"><?php echo e(strtoupper(str_replace('_', ' ', $invoice->status))); ?></span>
                                </td>
                            </tr>
                            <tr class="grand-total">
                                <td>Remaining:</td>
                                <td class="right"><?php echo e($formatCurrency($remainingAmount)); ?></td>
                            </tr>
                        </table>

                        <div class="signature-section">
                            <?php if($signatureBase64): ?>
                                <img src="<?php echo e($signatureBase64); ?>" class="signature-img" style="width:<?php echo e($signatureWidth); ?>px; height:<?php echo e($signatureHeight); ?>px;" alt="Signature" />
                            <?php else: ?>
                                <div class="signature-line">&nbsp;</div>
                            <?php endif; ?>
                            <div class="signature-text"><?php echo e($authorizedSignName); ?></div>
                            <div class="signature-caption">Authorised Sign</div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="footer-band"></div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Salivs\Data\laragon\www\drent-vibe\backend\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>